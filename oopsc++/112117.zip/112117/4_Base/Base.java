// Abstract classes can also have final methods (methods that cannot be
// overridden). For example, the following program compiles and runs fine.

abstract class Base {
    final void fun() { System.out.println("Derived fun() called"); }
}
  
class Derived extends Base {}
  
class Main {
    public static void main(String args[]) { 
       Base b = new Derived();
       b.fun();
    }
} 
