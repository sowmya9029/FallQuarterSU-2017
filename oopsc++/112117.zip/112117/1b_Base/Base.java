abstract class Base {
    abstract void fun();
}
