class Derived extends Base {
    void fun() { System.out.println("Derived fun() called"); }
}
