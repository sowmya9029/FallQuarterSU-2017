class Person
{
	private String name;
	private String suid;

	public Person(String n, String id) { name = n; suid = id; }
	public String getName() { return name; }
	public String getSUID() { return suid; }
	public void setName(String n) { name = n; }
	public void setSUID(String id) { suid = id; }
	public String toString() { return "name: " + name + "\nsuid: " + suid; }
	
	public boolean equals(Person p) 
	{  
		if (p == null) return false;
		return name.equals(p.getName()) && suid.equals(p.getSUID());
	}
	/*
	public boolean equals(Object o) 
	{
		if (o == null) 
			return false;
		else if (o.getClass() != getClass())
			return false;
		else
		{
			Person p = (Person)o;
			return name.equals(p.getName()) && suid.equals(p.getSUID());
		}
	}
	*/
}

class Student extends Person
{
	private int admitYear;
	private double gpa;
	
	public Student(String n, String id, int year, double gpa) 
	{
		super(n, id);
		admitYear = year;
		this.gpa = gpa;
	}
	public int getAdmitYear() { return admitYear; }
	public double getGPA() { return gpa; }
	public void setAdmitYear(int year) { admitYear = year; }
	public void setGPA(double gpa) { this.gpa = gpa; }
	public String toString() 
	{ 
		return super.toString() 
					+ "\nadmit year: " + admitYear + "\ngpa: " + gpa; 
	} 
	public boolean equals(Student s) 
	{ 
		if (s == null) return false;
		return super.equals(s) 
					&& admitYear == s.admitYear && gpa == s.gpa;
	} 
}

/*
public class Faculty extends Person
{
	private Faculty() { }
	// getter and setters
	// toString and equals
}
*/

interface Athlete
{
	public String getSport();
	public void setSport(String sport);
}

class StudentAthlete extends Student implements Athlete
{
	private String sport;

	public StudentAthlete(String n, String id, int year, double gpa, String s)
	{	
		super(n, id, year, gpa);
		sport = s;
	}

	public String getSport() { return sport; }
	public void setSport(String sport) { this.sport = sport; }

	public String toString()
	{
		return super.toString() + "\nsport: " + sport;
	}
}

class Main
{
	public static void main(String[] args)
	{
		Person pb = new Person("Bob", "123");
		Person pb2 = new Person("Bob", "123");
		Person pc = new Student("Carol", "234", 2017, 3.24);
		Person pb3 = new Student("Bob", "123", 2016, 3.41);

		if (pc instanceof Person)
			System.out.println("Carol is a person");
		else
			System.out.println("Carol is not a person");

		System.out.println(pb.equals(pb2));
		System.out.println(pb.equals(pc));
		System.out.println(pb.equals(pb3));

		Person pj = new StudentAthlete("Jane", "567", 2017, 3.55, "Golf");
		System.out.println(pj.toString());
	}
}
