public interface Sports {
   public void setHomeTeam(String name);
   public void setVisitingTeam(String name);
}
