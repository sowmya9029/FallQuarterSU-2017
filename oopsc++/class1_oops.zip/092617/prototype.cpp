// lines 6-8: function prototypes
// lines 
#include <iostream>
using namespace std;

void test1();
void test2();
void test3();

int main()
{
	test1();
	test2();
	test3();
}

void test1()
{
	cout << "test 1\n";
}

void test2()
{
	cout << "test 2\n";
}

void test3()
{
	cout << "test 3\n";
}
